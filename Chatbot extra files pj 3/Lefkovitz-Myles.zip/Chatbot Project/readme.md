KBAI Chatbot Alternate Project 3 Readme
===========

Myles Lefkovitz

gth836x

901929700

Run instructions
-

- No extra packages used
- All changed code is in Chatbot.py (basic method calls) and ChatbotAI.py (where the methods live)
- To run the chatbot from a script, run ChatbotAutograder.py